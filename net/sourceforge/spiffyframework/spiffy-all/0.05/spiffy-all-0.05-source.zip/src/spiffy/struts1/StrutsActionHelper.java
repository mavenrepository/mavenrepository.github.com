package spiffy.struts1;

import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * Helper class for Struts1 actions
 * 
 * @author Kasper B. Graversen, (c) 2007-2008
 * @since 0.03
 */

public class StrutsActionHelper {
	
	/**
	 * Helps you forwarding from one one action to another action and carrying over the parameters. If not carried over,
	 * they disappear from the request scope during forward.
	 * <p>
	 * A common use case is to have the <tt>SaveAction</tt> invoke the <tt>DislayListAction</tt>. To do this in a
	 * fashion that changes the URL in the users browser, you set the <tt>redirect="true"</tt> in the action in
	 * <tt>struts-config.xml</tt> and by uisng this helper method. It will take whatever you info you provide and
	 * encode the url to redict to.
	 * 
	 * @param actionMapping
	 *            Your Struts object
	 * @param forwardName
	 *            Name of the action in the struts-config.xml
	 * @param urlParams
	 *            An array of strings where you already have set all the values as strings, e.g. strings such as
	 *            <tt>"id=1"</tt>, <tt>name="Mr. Anderson"</tt>
	 * @return A struts forwarderder object
	 * @throws IllegalStateException
	 *             if redirect="true" is not set in the struts config or if forward path is invalid.
	 */
	public ActionForward goForward(final ActionMapping actionMapping, final String forwardName, final String[] urlParams) {
		// is forwarder defined in the config file?
		final ActionForward forward = actionMapping.findForward(forwardName);
		if( forward == null ) { return null; }
		
		// if redirect="false" is set in the config
		if( forward.getRedirect() == false ) { throw new IllegalStateException(
				"You must set your redirect='true' in your struts-config.xml for this action!"); }
		
		// Construct a URL
		final StringBuilder url = new StringBuilder();
		if( forward.getPath() == null ) { throw new IllegalStateException(
				"Can't find path to forward to in you struts-config.xml"); }
		
		url.append(forward.getPath());
		for(int i = 0; i < urlParams.length; i++) {
			url.append(i == 0 ? "?" : "&");
			url.append(urlParams[i]);
		}
		
		// Create a ActionForward object as Stuts does not allow to modify the existing one
		return new ActionForward(forward.getName(), url.toString(), true /* = REDIRECT */);
	}
	
	// TODO we should also have a method that takes the request scope and converts it into an Object array, so it is
	// easy to transfer the request scope
};
